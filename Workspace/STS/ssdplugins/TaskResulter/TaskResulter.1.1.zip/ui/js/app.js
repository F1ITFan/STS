(function () {
  'use strict';

	var app = angular.module('taskResulter', []);

	app.controller('taskResulterController', ['$scope', '$http', function($scope, $http) {

		var noTaskSelectedMessage = "No task result selected ...";

		//Lets not show result panels initially
		this.showMainPanel = false;
		this.showPartitionedResults = false;
		this.showEstimates = false;


    $http({
            method  : "GET",
            withCredentials: true,
            xsrfHeaderName : "X-XSRF-TOKEN",
            xsrfCookieName : "CSRF-TOKEN",
            url : PluginHelper.getPluginRestUrl('taskResults') + '/getApplications'
        }).then(function mySuccess(response) {

			    var dataSize = response.data.shift();
			    console.log("Application count: "+ dataSize.appCount);
			    $scope.appData = response.data;
			    $scope.appData.unshift({"appName":"NA", "displayAppName":"No application selected ..."});

        }, function myError(response) {
          alert("We hit an error initializing the GET request");
    });

    $http({
            method  : "GET",
            withCredentials: true,
            xsrfHeaderName : "X-XSRF-TOKEN",
            xsrfCookieName : "CSRF-TOKEN",
            url : PluginHelper.getPluginRestUrl('taskResults') + '/getList'
        }).then(function mySuccess(response) {

          if(response.data.message.length > 0) {
            $scope.resultList = response.data.message;
            $scope.resultList.unshift([noTaskSelectedMessage, noTaskSelectedMessage]);
          } else { //not task results in the system at all
            $scope.resultList = [];
            $scope.resultList.push(["No task results", "No task results"]);
          }
          $scope.showInvokeButton = false;
        }, function myError(response) {
          alert("We hit an error initializing the GET request");
    });


		// run when application drop down changes
		$scope.updateResultList = function() {
			var noTaskSelectedMessage = "No task result selected ...";
      var params = {};
			if($scope.selectedApplication !== "NA") {
			  params = {appName: $scope.selectedApplication}
			}

      $http({
              method  : "GET",
              withCredentials: true,
              xsrfHeaderName : "X-XSRF-TOKEN",
              xsrfCookieName : "CSRF-TOKEN",
              params : params,
              url : PluginHelper.getPluginRestUrl('taskResults') + '/getList'
          }).then(function mySuccess(response) {
            if(response.data.message.length == 0 ) { // no task results returned

              if($scope.selectedApplication === "NA") { // no application was selected
                var noResultsMessage = "No task results";
              } else {//some application was selected
                var noResultsMessage = "No task results for application";
              }

              $scope.resultList = [];
              $scope.resultList.push([noResultsMessage, noResultsMessage]);
              $scope.selectedTaskResult = noResultsMessage;
              $scope.showInvokeButton = false;
              $scope.showMainPanel = false;
              $scope.showPartitionedResults = false;
            } else {// some task results were returned

              $scope.resultList = response.data.message;
              if($scope.selectedApplication === "NA") { // no application was selected
                $scope.resultList.unshift([noTaskSelectedMessage, noTaskSelectedMessage]);
              }
              $scope.selectedTaskResult = response.data.message[0][0];
              $scope.showInvokeButton = true;
            }
          }, function myError(response) {
            alert("We hit an error initializing the GET request");
      });

		}

	    $scope.calcualteResults = function () {
        $http({
              method  : "GET",
              withCredentials: true,
              xsrfHeaderName : "X-XSRF-TOKEN",
              xsrfCookieName : "CSRF-TOKEN",
              params : {taskResultName: $scope.selectedTaskResult},
              url : PluginHelper.getPluginRestUrl('taskResults') + '/getTaksResultCalcualtion'
          }).then(function mySuccess(response) {


	    		$scope.resultName = response.data.resultName;
	    		$scope.status = response.data.status;
	    		$scope.started = response.data.started;
	    		$scope.finished = response.data.finished;
	    		$scope.totalr = response.data.total;
          $scope.optimized = response.data.optimized;
          $scope.ignored = response.data.ignored;
          $scope.updated = response.data.updated;
          $scope.speed = response.data.speed;
          $scope.procDuration = response.data.durationString;

          //we can show the main result panel now
          $scope.showMainPanel = true;
          $scope.showInvokeButton = true;

	    		if (response.data.partialResults === null || response.data.partialResults.length === 0) {
	    			$scope.showPartitionedResults = false;
          } else {
            $scope.partitions = response.data.partialResults;
            $scope.showPartitionedResults = true;
          }

	    		$scope.showEstimates = false;
          if(response.data.estimatedTimeLeft !== null) {
            $scope.estimatedTimeLeft = response.data.estimatedTimeLeft;
            $scope.showEstimates = true;
          }

          $scope.rawData = response.data;


          }, function myError(response) {
            alert("We hit an error initializing the GET request");
      });
	    }
	}]);
}());